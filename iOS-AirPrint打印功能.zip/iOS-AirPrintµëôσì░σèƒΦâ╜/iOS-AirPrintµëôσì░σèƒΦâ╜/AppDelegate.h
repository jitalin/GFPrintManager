//
//  AppDelegate.h
//  iOS-AirPrint打印功能
//
//  Created by 高飞 on 17/3/3.
//  Copyright © 2017年 高飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

